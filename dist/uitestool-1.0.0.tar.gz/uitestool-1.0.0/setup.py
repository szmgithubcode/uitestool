from setuptools import find_packages, setup
setup(
    name='uitestool',
    version='1.0.0',
    description='a automated test tools',
    author='szmgithubcode',
    author_email='13023297816@163.com',
    url='https://github.com/szmgithubcode/',
    #packages=find_packages(),
    packages=['autotest'],
    #install_requires=['requests'],
)